package com.example.mytheduc;

import android.view.View;

public interface OnClickItem {
    void onClickItem(View view, int position);
}
